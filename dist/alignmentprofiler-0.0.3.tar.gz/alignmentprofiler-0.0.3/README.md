# AlignmentProfiler

A package to get summary statistics and diagnostics for a multiple sequence alignment
